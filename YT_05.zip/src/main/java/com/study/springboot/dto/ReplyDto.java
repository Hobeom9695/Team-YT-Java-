package com.study.springboot.dto;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class ReplyDto {
	private int id;
	private String contentid;
	private String writer;
	private String content;
	private Timestamp createdate;
}
