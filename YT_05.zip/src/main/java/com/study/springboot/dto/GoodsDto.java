package com.study.springboot.dto;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class GoodsDto {
	private int id;
	private String writer;
	private String title;
	private int price;
	private String content;
	private Timestamp createdate;
	private int hit;
}