package com.study.springboot.dto;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class NoticeDto {
	private int id;
	private String writer;
	private String title;
	private String contentText;
	private int hit;
	private Timestamp createdate;
}
