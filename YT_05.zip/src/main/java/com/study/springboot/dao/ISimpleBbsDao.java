package com.study.springboot.dao;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.ui.Model;

import com.study.springboot.dto.ReplyDto;
import com.study.springboot.dto.SimpleBbsDto;

@Mapper
public interface ISimpleBbsDao {
	public List<SimpleBbsDto> listDao(Map<String, Integer> map);
	public List<ReplyDto> replylistDao(String id);
	public List<SimpleBbsDto> searchDaoT(String sPlace);
	public List<SimpleBbsDto> searchDaoC(String sPlace);
	public SimpleBbsDto viewDao(String id);
	public void upHit(String id);
	public int writeDao(Map<String, String> map);
	public int writereplyDao(Map<String, String> map);
	public int modifyDao(Map<String, String> map);
	public int deleteDao(@Param("_id")String id);
	public int deletereplyDao(@Param("_id")String id);
	public int articleCount();
}