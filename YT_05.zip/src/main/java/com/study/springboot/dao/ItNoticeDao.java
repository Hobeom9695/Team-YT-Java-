package com.study.springboot.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.study.springboot.dto.NoticeDto;

@Mapper
public interface ItNoticeDao {
	public List<NoticeDto> noticeList(Map<String, Integer> map);//
	public List<NoticeDto> searchDaoT(String sPlace);
	public List<NoticeDto> searchDaoC(String sPlace);
	public NoticeDto noticeviewDao(String id);
	public void upHit(String id); //??
	public int noticeWrite(Map<String, String> map);//
	public int modifyDao(Map<String, String> map);
	public int deleteDao(@Param("_id")String id);
	public int noticeCount();//
}
