package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YT_05Application {

	public static void main(String[] args) {
		SpringApplication.run(YT_05Application.class, args);
	}

}
