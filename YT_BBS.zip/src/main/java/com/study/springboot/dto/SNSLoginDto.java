package com.study.springboot.dto;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class SNSLoginDto {
	private int usernum;
	private String snsid;
	private String snstype;
	private String snsname;
	private String snsnickname;
	private Timestamp snsconnectdate;
	private String grade;
}
