package com.study.springboot;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.json.ParseException;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.study.springboot.dao.ISimpleBbsDao;
import com.study.springboot.dto.SimpleBbsDto;

@Controller
public class MyController {
	
	@Autowired
	ISimpleBbsDao dao;
	
	@RequestMapping("/")
	public String root() throws Exception {
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String userlistPage(Model model) {
		model.addAttribute("list", dao.listDao());
		
		int nTotalCount = dao.articleCount();
		System.out.println("Count : " + nTotalCount);
		
		return "/list";
	}
	
	@RequestMapping("/view")
	public String view(HttpServletRequest request, Model model) {
		String sId = request.getParameter("id");
		model.addAttribute("dto", dao.viewDao(sId));
		return "/view";
	}
	
	@RequestMapping("/writeForm")
	public String writeForm() {
		return "/writeForm";
	}
	
	@RequestMapping("/basic")
	public String basic() {
		return "/basic";
	}
	
	@RequestMapping("/pn")
	public String pn(HttpSession session) {
		return "/pn";
	}
	
	@RequestMapping("/callback")
	public String pn_(HttpServletRequest session) throws Exception {
		return "/callback";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request, Model model) {
		String sName = request.getParameter("writer");
		String sTitle = request.getParameter("title");
		String sContent = request.getParameter("content");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("item1", sName);
		map.put("item2", sTitle);
		map.put("item3", sContent);
		
		int nResult = dao.writeDao(map);
		System.out.println("Write : " + nResult);
		return "redirect:list";
	}
	
	@RequestMapping("/joinNaver")
	public String joinNaver(HttpServletRequest request, Model model) {
		String nId = request.getParameter("nId");
		String nName = request.getParameter("nName");
		String nEmail = request.getParameter("nEmail");
		String nNickname = request.getParameter("nNickname");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("item1", nId);
		map.put("item2", nName);
		map.put("item3", nEmail);
		map.put("item4", nNickname);
		
		
		int nResult = dao.joinNaver(map);
		System.out.println("Join Naver : " + nResult);
		return "redirect:list";
	}
	
	@RequestMapping("/modifyForm")
	public String modifyForm(HttpServletRequest request, Model model) {
		String sId = request.getParameter("id");
		model.addAttribute("dto", dao.viewDao(sId));
		return "/modifyForm";
	}
	
	@RequestMapping("/personalInfo")
	public void personalInfo(HttpServletRequest request) throws Exception {
		String token = "AAAAODbfW92mOVeCWEwwFExoN5vcMkdW_DPhcihZdv0uKfK7j0b_30Wo3KqrSnm6OMOshAjRRiO_NTDdCMzxx7LE9Z8";
		String header = "Bearer " + token;
		try {
			String apiURL="https://openapi.naver.com/v1/nid/me";
			URL url = new URL(apiURL);
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestProperty("Authorization", header);
			int responseCode = con.getResponseCode();
			BufferedReader br;
			if(responseCode==200) {
				br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			} else {
				br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
			}
			String inputLine;
			StringBuffer response = new StringBuffer();
			while((inputLine = br.readLine())!= null) {
				System.out.println(inputLine);
				response.append(inputLine);
			}
			br.close();
			System.out.println(response.toString());
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	@RequestMapping("/modify")
	public String modify(HttpServletRequest request, Model model) {
		String sId = request.getParameter("id");
		String sTitle = request.getParameter("title");
		String sContent = request.getParameter("content");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("item1", sTitle);
		map.put("item2", sContent);
		map.put("item3", sId);
		
		int nResult = dao.modifyDao(map);
		System.out.println("Modify : " + nResult);
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		String sId = request.getParameter("id");
		int nResult = dao.deleteDao(sId);
		System.out.println("Delete : " + nResult);
		
		return "redirect:list";
	}
}
