package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YT_04Application {

	public static void main(String[] args) {
		SpringApplication.run(YT_04Application.class, args);
	}

}
