package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectYt01Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectYt01Application.class, args);
	}

}
